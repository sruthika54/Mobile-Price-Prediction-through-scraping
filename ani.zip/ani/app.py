import os
import pickle
from flask import Flask, render_template, request
from forms import InfoForm  
import numpy as np

app = Flask(__name__)
app.config['SECRET_KEY'] = 'mysecretkey'

model = pickle.load(open(r"C:\Users\91953\OneDrive\Desktop\ani\abc.pkl", 'rb'))

@app.route('/', methods=['GET', 'POST'])
def index():
    form = InfoForm()
    price = None

    if form.validate_on_submit():
        product = [float(x) for x in form.product.data.split(',')]
        scnsize = float(form.scnsize.data)
        scntype = [float(x) for x in form.scntype.data.split(',')]
        batpower = float(form.batpower.data)
        processor = [float(x) for x in form.processor.data.split(',')]
        ram = float(form.ram.data)
        inbuilt = float(form.inbuilt.data)
        external = float(form.external.data)
        fcam = float(form.fcam.data)
        rcam = float(form.rcam.data)
        os_data = [float(x) for x in form.os.data.split(',')]

        final_features = product + [scnsize] + scntype + [batpower] + processor + [ram, inbuilt, external, fcam, rcam] + os_data

        pred_array = np.array(final_features).reshape(1, -1)

        price = model.predict(pred_array)[0]
        #price += 9900
    return render_template('index.html', form=form, price=(price))

if __name__ == '__main__':
    app.run(debug=True)
